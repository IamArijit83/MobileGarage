package com.mycompany.anushthan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
