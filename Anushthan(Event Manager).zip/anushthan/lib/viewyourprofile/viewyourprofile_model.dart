import '/flutter_flow/flutter_flow_util.dart';
import 'viewyourprofile_widget.dart' show ViewyourprofileWidget;
import 'package:flutter/material.dart';

class ViewyourprofileModel extends FlutterFlowModel<ViewyourprofileWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
