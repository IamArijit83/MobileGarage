import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyASlN7G_-lov3O36CdxefWTmRiU-K7QX8g",
            authDomain: "anushthan-b98ef.firebaseapp.com",
            projectId: "anushthan-b98ef",
            storageBucket: "anushthan-b98ef.appspot.com",
            messagingSenderId: "435732154146",
            appId: "1:435732154146:web:d45714f7eed57249d6477b"));
  } else {
    await Firebase.initializeApp();
  }
}
