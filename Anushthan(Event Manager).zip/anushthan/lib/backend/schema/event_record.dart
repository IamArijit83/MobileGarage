import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class EventRecord extends FirestoreRecord {
  EventRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "eventname" field.
  String? _eventname;
  String get eventname => _eventname ?? '';
  bool hasEventname() => _eventname != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "typeofevent" field.
  String? _typeofevent;
  String get typeofevent => _typeofevent ?? '';
  bool hasTypeofevent() => _typeofevent != null;

  // "user" field.
  DocumentReference? _user;
  DocumentReference? get user => _user;
  bool hasUser() => _user != null;

  // "created" field.
  DateTime? _created;
  DateTime? get created => _created;
  bool hasCreated() => _created != null;

  void _initializeFields() {
    _eventname = snapshotData['eventname'] as String?;
    _description = snapshotData['description'] as String?;
    _typeofevent = snapshotData['typeofevent'] as String?;
    _user = snapshotData['user'] as DocumentReference?;
    _created = snapshotData['created'] as DateTime?;
  }

  static CollectionReference get collection => FirebaseFirestore.instanceFor(
          app: Firebase.app(),
          databaseURL:
              'https://anushthan-b98ef-default-rtdb.asia-southeast1.firebasedatabase.app/')
      .collection('Event');

  static Stream<EventRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => EventRecord.fromSnapshot(s));

  static Future<EventRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => EventRecord.fromSnapshot(s));

  static EventRecord fromSnapshot(DocumentSnapshot snapshot) => EventRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static EventRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      EventRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'EventRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is EventRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createEventRecordData({
  String? eventname,
  String? description,
  String? typeofevent,
  DocumentReference? user,
  DateTime? created,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'eventname': eventname,
      'description': description,
      'typeofevent': typeofevent,
      'user': user,
      'created': created,
    }.withoutNulls,
  );

  return firestoreData;
}

class EventRecordDocumentEquality implements Equality<EventRecord> {
  const EventRecordDocumentEquality();

  @override
  bool equals(EventRecord? e1, EventRecord? e2) {
    return e1?.eventname == e2?.eventname &&
        e1?.description == e2?.description &&
        e1?.typeofevent == e2?.typeofevent &&
        e1?.user == e2?.user &&
        e1?.created == e2?.created;
  }

  @override
  int hash(EventRecord? e) => const ListEquality().hash(
      [e?.eventname, e?.description, e?.typeofevent, e?.user, e?.created]);

  @override
  bool isValidKey(Object? o) => o is EventRecord;
}
