// Export pages
export '/authorization/authorization_widget.dart' show AuthorizationWidget;
export '/homepage/homepage_widget.dart' show HomepageWidget;
export '/onboarding/onboarding_widget.dart' show OnboardingWidget;
export '/createevent/createevent_widget.dart' show CreateeventWidget;
export '/created/created_widget.dart' show CreatedWidget;
export '/viewyourprofile/viewyourprofile_widget.dart'
    show ViewyourprofileWidget;
